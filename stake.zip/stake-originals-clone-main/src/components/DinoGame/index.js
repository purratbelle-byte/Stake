export { default } from './DinoGame';
